global conn vert

conn = load('conn.txt');
vert = load('vert.txt');
